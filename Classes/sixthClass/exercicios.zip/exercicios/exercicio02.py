
for cont in range(1,16):
    notaUm = float(input("Digite a nota do primeiro checkpoint:"))
    notaDois = float(input("Digite a nota do segundo checkpoint:"))
    notaTres = float(input("Digite a nota do terceiro checkpoint:"))
    media = (notaUm + notaDois + notaTres)/3
    print("Sua média dos três checkpoints é:", media)
