
soma = 0

for cont in range(1,21):
    if (cont % 2 == 0):
        soma = soma + cont
print("Soma dos numeros pares (1 a 20):", soma)