for seq in range(1,31):
    if (seq % 4 == 0):
        print("PIM")
    else:
        print(seq)
