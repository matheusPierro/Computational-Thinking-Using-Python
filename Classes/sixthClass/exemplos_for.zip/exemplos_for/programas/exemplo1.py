


for cont in range(1,11): #para cont dentro faixa de 1 a 10
    print(cont)