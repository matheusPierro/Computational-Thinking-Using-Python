
soma = 0

for cont in range(1,11):
    num = int(input("Digite um número: "))
    soma = soma + num

print("Soma total: ", soma)