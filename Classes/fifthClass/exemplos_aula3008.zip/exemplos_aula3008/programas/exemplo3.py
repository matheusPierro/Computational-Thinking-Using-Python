dia_semana = int(input("Digite o dia da semana: "))

if (dia_semana==0):
    print("Domingo")
elif (dia_semana==1):
    print("Segunda-feira")
elif (dia_semana==2):
    print("Terça-feira")
elif (dia_semana==3):
    print("Quarta-feira")
elif (dia_semana==4):
    print("Quinta-feira")
elif (dia_semana==5):
    print("Sexta-feira")
elif (dia_semana==6):
    print("Sábado")
else:
    print("Dia inválido")

