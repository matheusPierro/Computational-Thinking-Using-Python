num = int(input("Digite o valor de num: "))

if (num>=1 and num<=10):
    print("Num está entre 1 e 10")

if (num>=11 and num<=20):
    print("Num está entre 11 e 20")

if (num>=21 and num<=30):
    print("Num está entre 21 e 30")


