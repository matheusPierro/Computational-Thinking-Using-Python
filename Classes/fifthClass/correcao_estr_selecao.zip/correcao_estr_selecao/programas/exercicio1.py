bloco_morador = int(input("Digite o bloco onde mora (1-4): "))

resto = bloco_morador % 2

if (resto==0): # if (bloco_morador % 2 == 0)
    print("Seu bloco é abastecido pela caixa d'água A")
else:
    print("Seu bloco é abastecido pela caixa d'água B")