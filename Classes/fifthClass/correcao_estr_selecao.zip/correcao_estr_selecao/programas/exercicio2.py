bloco_morador = int(input("Digite o bloco onde mora (1-20): "))

if (bloco_morador>=1 and bloco_morador<=10):
    print("Síndico responsável: Sr. José")

if (bloco_morador>=11) and (bloco_morador<=20):
    print("Síndico responsável: Sr. Hamilton")