periodo_perm = float(input("Digite o tempo de permanência em horas: "))

valor_total = periodo_perm*5.00

if (valor_total<=35.00):
    print(f"Valor total a pagar: R${valor_total:.2f}")
else:
    print(f"Valor total a pagar: R$35.00")