valor_mercadoria = float(input("Qual o valor da mercadoria? "))
valor_usuario = float(input("Qual o valor o usuário tem em mãos? "))

if (valor_usuario>=valor_mercadoria):
    print("O valor que o usuário tem é suficiente para comprar a mercadoria!")
else:
    print("O valor que o usuário tem não é suficiente para comprar a mercadoria!")