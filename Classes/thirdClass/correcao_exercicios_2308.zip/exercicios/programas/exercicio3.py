base = input("Digite a base do triângulo: ")
base = float(base)
altura = input("Digite a altura do triângulo: ")
altura = float(altura)


area = (base*altura)/2

print(f"Área do triângulo: {area:.2f}")