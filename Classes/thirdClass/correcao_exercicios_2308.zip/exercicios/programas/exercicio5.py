salario = input("Digite o salário do funcionário: ")
salario = float(salario)

novo_salario = salario * 1.20

print(f"Novo salário: {novo_salario:.2f}")