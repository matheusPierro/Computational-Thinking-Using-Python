peso = input("Digite o peso: ")
peso = float(peso)
altura = input("Digite a altura: ")
altura = float(altura)


IMC = peso/altura**2 # IMC = peso/(altura * altura)

print(f"Seu IMC é: {IMC:.2f}")