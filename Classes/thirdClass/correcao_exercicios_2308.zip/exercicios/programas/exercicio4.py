x = input("Digite o valor de x: ")
x = int(x)

dobro = 2*x

print("Dobro de x: ", dobro)