# Leitura das variáveis de entrada

num1 = input("Digite o primeiro número: ")
num1 = int(num1)
num2 = input("Digite o segundo número: ")
num2 = int(num2)

# Processamento dos dados (soma, subtração e multiplicação)

soma = num1 + num2
sub = num1 - num2
mult = num1 * num2

# Saída dos dados

print("Soma: ", soma)
print("Subtração: ", sub)
print("Multiplicação: ", mult)

