lado1 = input("Digite o primeiro lado: ")
lado1 = int(lado1)
lado2 = input("Digite o segundo lado: ")
lado2 = int(lado2)
lado3 = input("Digite o terceiro lado: ")
lado3 = int(lado3)

perimetro = lado1 + lado2 + lado3

print("Perímetro do triângulo: ", perimetro)