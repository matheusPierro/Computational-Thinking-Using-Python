km = input("Km percorrida: ")
km = float(km)

l = input("Litros gastos: ")
l = float(l)

autonomia = km / l

print(f"Autonomia: {autonomia:.2f} km/l")