idade = int(input("Digite sua idade: "))

if (idade>=18) and (idade<=67):
    print("Você pode doar sangue!")
else:
    print("Você não pode doar sangue!")