num = input("Digite um número real: ")
num = float(num)

if num>=0:
    print("O número é positivo")
else:
    print("O número é negativo")